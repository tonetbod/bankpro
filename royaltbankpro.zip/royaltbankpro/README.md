Bankpro Script

Email Developer: tonetbod@gmail.com

Phone Number: 08039121642



*** How to upload ***

// Download and Extract File.zip to public directory or sub folder

// Create a New Database and Import database.sql file

// Edit the /include/Config.php and set database

// Scroll down for smtp settings





*** How to Set Up SMTP ***

Locate  The SMTP.php in include folder and Use default configurations on Email account  in Cpanel


testing mail smtp
CREATE A MAIL AND KNOW THE PASSWORD


*** Demo User Logins ***


hosting link OR lOCAL HOST

royalcou  un
@massby01  pw


Account id: 0022521726

Password: test

pin: 1234

