<?php
header("Location:verify-registration.php");