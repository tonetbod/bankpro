<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
   // $name = $_POST['name'];
    $emailList = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $fromEmail = $_POST['fromEmail'];

    // Split the email list into individual email addresses
    $recipients = explode(',', $emailList);
    $recipients = array_map('trim', $recipients);

    // Prepare email content
    // $content = "Name: $name\nEmail: $emailList\nSubject: $subject\nMessage: $message";
    $content = "Subject: $subject\nMessage: $message";
    
    $apiKey = '109e5fde6fmsh35f6d3638723680p14b222jsnad247b16343c'; // Replace with your SendGrid API key
    $curl = curl_init();

    foreach ($recipients as $recipient) {
        $data = [
            'personalizations' => [
                [
                    'to' => [
                        ['email' => $recipient]
                    ],
                    'subject' => $subject
                ]
            ],
            'from' => [
                'email' => $fromEmail
            ],
            'content' => [
                [
                    'type' => 'text/plain',
                    'value' => $content
                ]
            ]
        ];

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://rapidprod-sendgrid-v1.p.rapidapi.com/mail/send",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                "X-RapidAPI-Host: rapidprod-sendgrid-v1.p.rapidapi.com",
                "X-RapidAPI-Key: " . $apiKey,
                "content-type: application/json"
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);


        # left corner toast
    /*if ($err) {
        echo '<div class="toast bg-danger text-white" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
                <div class="toast-body">
                    <strong>Error:</strong> cURL Error for recipient ' . $recipient . ': ' . $err . '
                </div>
              </div>';
    } else {
        echo '<div class="toast bg-success text-white" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
                <div class="toast-body">
                    Email sent successfully to ' . $recipient . '
                </div>
              </div>';
    }*/

//botttom right 
/*if ($err) {
    echo '<div class="toast bg-danger text-white position-absolute bottom-0 end-0" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
            <div class="toast-body">
                <strong>Error:</strong> cURL Error for recipient ' . $recipient . ': ' . $err . '
            </div>
          </div>';
} else {
    echo '<div class="toast bg-success text-white position-absolute bottom-0 end-0" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
            <div class="toast-body">
                Email sent successfully to ' . $recipient . '
            </div>
          </div>';
}
*/

//right corner toast
/*if ($err) {
    echo '<div class="toast bg-danger text-white position-absolute top-0 end-0" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="5000">
            <div class="toast-body">
                <strong>Error:</strong> cURL Error for recipient ' . $recipient . ': ' . $err . '
            </div>
          </div>';
} else {
    echo '<div class="toast bg-success text-white position-absolute top-0 end-0" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="5000">
            <div class="toast-body">
                Email sent successfully to ' . $recipient . '
            </div>
          </div>';
}

   
*/

// like modal close sign

if ($err) {
    echo '<div class="toast bg-danger text-white position-absolute top-0 end-0" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false">
            <div class="toast-header">
                <strong class="me-auto">Error</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                cURL Error for recipient ' . $recipient . ': ' . $err . '
            </div>
          </div>';
} else {
    echo '<div class="toast bg-success text-white position-absolute top-0 end-0" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false">
            <div class="toast-header">
                <strong class="me-auto">LeadApp</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                Email sent successfully to ' . $recipient . '
            </div>
          </div>';
}

    
}

    curl_close($curl);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>EMAIL FORWARDING</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container mt-3">

    <form method="POST" action="">
       <!-- <label for="name">Name:</label>
        <input type="text" name="name" id="name" required><br>-->
        


 <div class="container-fluid p-5 bg-primary text-white text-center">
  <h1>LEADAPP EMAIL FORWARDING </h1>
  
</div>
<p></p> 
<BR>
        <div class="form-outline w-27">
        <div class="row">
        <div class="col">

        <B><pre><label for="fromEmail">From Email</label></pre></B>
        <input type="email" class="form-control" name="fromEmail" id="fromEmail" value = "babaibeji@gmail.com"  required>
        </div> 
       
      
        <div class="col">

        <B><pre> <label for="email">Email List</label></pre></B>
        <textarea class="form-control" rows="5" id="email" name="email"  placeholder="Enter multiple email addresses separated by commas" required></textarea>

        </div></div></div>
      
        <p></p>
        <br><br>

       <div class="form-outline w-27">
        <div class="row">
        <div class="col">


        <B><pre> <label for="subject">Subject</label></pre></B>
        <input type="text" class="form-control"  name="subject" id="subject" required>

        </div> 


        <div class="col">
     
        <B><pre><label for="message">Message</label></pre></B>
      <textarea class="form-control" rows="5" id="message" name="message" required></textarea><br><br>
    </div>   </div>   </div>

        
   <div class="form-outline w-25">

        <input type="submit" class="form-control btn btn-primary " value="Submit">
        </div>
       
    </form>

      <script>
  var toastElList = [].slice.call(document.querySelectorAll('.toast'));
  var toastList = toastElList.map(function (toastEl) {
    return new bootstrap.Toast(toastEl);
  });
  toastList.forEach(function (toast) {
    toast.show();
  });
</script>






</body>
</html>