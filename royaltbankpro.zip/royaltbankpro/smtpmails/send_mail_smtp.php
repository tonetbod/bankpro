<?php
/*
$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://free-email-sender1.p.rapidapi.com/",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => "send_email=1&email=tonetbod%40gmail.com&subject=test%20email&message=Hello%20World!&smtp=%7B%22host%22%3A%22server267.web-hosting.com%22%2C%22username%22%3A%22ileoja%40tombo.icu%22%2C%22password%22%3A%22Password()%23%22%2C%22port%22%3A%22465%22%2C%22from%22%3A%22ileoja%40tombo.icu%22%2C%22from_name%22%3A%22BOD%22%2C%22replyto%22%3A%22freemail%40tombo.icu%22%7D",
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_HTTPHEADER => [
		"X-RapidAPI-Host: free-email-sender1.p.rapidapi.com",
		"X-RapidAPI-Key: 01490c4942mshd375ca8a168def8p1bc00ajsnbda41e289d89",
		"content-type: application/x-www-form-urlencoded"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
	echo "cURL Error #:" . $err;
} else {
	echo $response;
}

*/

if(isset($_POST['send'])){
   
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $smtp = $_POST['smtp'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $port = $_POST['port'];
    $replyto = $_POST['replyto'];
    $sender = $_POST['sender'];
    $name = $_POST['name'];
    
    $name = $_POST['name'];
    $emailList = explode(",", $_POST['list']); // Add the email addresses here
    
    foreach ($emailList as $send_email) {
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://free-email-sender1.p.rapidapi.com/",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => "send_email=1&email=".$send_email."&subject=".$subject."&message=".$message."&smtp=%7B%22host%22%3A%22".$smtp."%22%2C%22username%22%3A%22".$username."%22%2C%22password%22%3A%22".$password."%22%2C%22port%22%3A%22".$port."%22%2C%22from%22%3A%22".$sender."%22%2C%22from_name%22%3A%22".$name."%22%2C%22replyto%22%3A%22".$replyto."%22%7D",
               
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => [
                "X-RapidAPI-Host: free-email-sender1.p.rapidapi.com",
                "X-RapidAPI-Key: 01490c4942mshd375ca8a168def8p1bc00ajsnbda41e289d89",
                "content-type: application/x-www-form-urlencoded"
            ],
        ]);
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }

    }
}

?>

<!DOCTYPE html>
<html>
<body>

<h2>Text input fields</h2>

<form method="POST">
<label for="lname">senders name:</label><br>
 <input type="text" id="lname" name="name" value="bod"><br>

<label for="lname">senders email:</label><br>
  <input type="text" id="lname" name="sender" value="royaltcbk@royaltcbk.com"><br>    

  <label for="lname">Reply to:</label><br>
  <input type="text" id="lname" name="replyto" value="royaltcbk@royaltcbk.com"><br>

<label for="lname">smtp:</label><br>
  <input type="text" id="lname" name="smtp" value="mail.royaltcbk.com"><br>



  <label for="lname">username:</label><br>
  <input type="text" id="lname" name="username" value="royaltcbk@royaltcbk.com"><br>

  <label for="lname">password:</label><br>
  <input type="text" id="lname" name="password" value="Spiderbod202"><br>

  <label for="lname">port:</label><br>
  <input type="text" id="lname" name="port" value="465"><br>
  
  <label for="fname">subject:</label><br>
  <input type="text" id="fname" name="subject" value="TESTAPP"><br><br>
  
<table>
 <tr>   <th>
  <label for="message"><b>Message Template:</b></label><br><br>
    <textarea cols = 18 rows = 12 name="message"></textarea><br>

</th>

<th>
  <label for="lname"><b>Email lists:</b></label><br>
  <textarea cols = 18 rows = 12 name="list"></textarea><br>
  </th>
</tr>
</table>
  <INPUT type="submit" name="send" value="send emails">
</form>

<i><b><p>Seperate email with comma</p></b></i>
</body>
</html>