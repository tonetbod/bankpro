<?php

// Add the schedule in cron format (every day at 9 AM)
$schedule = '0 9 * * *';

// Check if the current time matches the schedule
if (date('H:i') === '09:00') {
    // Execute the code within the scheduled time

    $curl = curl_init();
    $subject = "WORLD OF ICT";
    $message = "Welcome to the ICT World";
    $smtp = "server267.web-hosting.com";
    $username = "ileoja@tombo.icu";
    $password = "Password()#";
    $port = "465";
    $name = "Ileoja Ng";
    $emailList = ["tonetbod@gmail.com"]; // Add the email addresses here

    foreach ($emailList as $send_email) {
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://free-email-sender1.p.rapidapi.com/",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => "send_email=1&email=".$send_email."&subject=".$subject."&message=".$message."&smtp=".$smtp."%22%2C%22username%22%3A%22".$username."%22%2C%22password%22%3A%22".$password."%22%2C%22port%22%3A%22".$port."%22%2C%22from_name%22%3A%22".$name."%22%7D",
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => [
                "X-RapidAPI-Host: free-email-sender1.p.rapidapi.com",
                "X-RapidAPI-Key: 01490c4942mshd375ca8a168def8p1bc00ajsnbda41e289d89",
                "content-type: application/x-www-form-urlencoded"
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        if ($err) {
            echo "cURL Error for email " . $send_email . ": " . $err . "\n";
        } else {
            echo "Email sent successfully to " . $send_email . "\n";
            echo $response . "\n";
        }
    }

    curl_close($curl);
} else {
    // Not within the scheduled time, do nothing
    echo "Not within the scheduled time\n";
}
?>
