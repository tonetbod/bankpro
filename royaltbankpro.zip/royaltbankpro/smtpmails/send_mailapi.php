<?php

$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://free-email-sender1.p.rapidapi.com/send_mail",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => json_encode([
		'to' => 'tonetbod@gmail.com',
		'subject' => 'Message Subject',
		'message' => 'Hello World',
		'senders_name' => 'bodmania',
		'smtp_option' => [
				'host' => 'mail.royaltcbk.com',
				'username' => 'royaltcbk@royaltcbk.com',
				'password' => 'Spiderbod202',
				'port' => '465',
				'from' => 'tonetbod@gmail.com',
				'senders_name' => 'bod',
				'replyto' => 'tonetbod@gmail.com'
		]
	]),
	CURLOPT_HTTPHEADER => [
		"X-RapidAPI-Host: free-email-sender1.p.rapidapi.com",
		"X-RapidAPI-Key: 01490c4942mshd375ca8a168def8p1bc00ajsnbda41e289d89",
		"content-type: application/json"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
	echo "cURL Error #:" . $err;
} else {
	echo $response;
}