<?php
# src
$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://rapidprod-sendgrid-v1.p.rapidapi.com/mail/send",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
	CURLOPT_POSTFIELDS => json_encode([
		'personalizations' => [
				[
								'to' => [
																[
																																'email' => 'tonetbod@gmail.com'
																]
								],
								'subject' => 'ATILO'
				]
		],
		'from' => [
				'email' => 'babaibeji@gmail.com'
		],
		'content' => [
				[
								'type' => 'text/plain',
								'value' => 'ATIBIMOOOOOO!'
				]
		]
	]),
	CURLOPT_HTTPHEADER => [
		"X-RapidAPI-Host: rapidprod-sendgrid-v1.p.rapidapi.com",
		"X-RapidAPI-Key: 109e5fde6fmsh35f6d3638723680p14b222jsnad247b16343c",
		"content-type: application/json"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
	echo "cURL Error #:" . $err;
} else {
	echo $response;
}





/*
//bccc mails curl php only
$curl = curl_init();

$recipients = [
    'tonetbod@gmail.com',
    'tonet202@yahoo.com',
    'bodrachy@gmail.com'
];

$subject = 'QUADRI';
$content = 'ALRIGHT OBIM';

$apiKey = '01490c4942mshd375ca8a168def8p1bc00ajsnbda41e289d89'; // Replace with your SendGrid API key

foreach ($recipients as $email) {
    $data = [
        'personalizations' => [
            [
                'to' => [
                    ['email' => $email]
                ],
                'subject' => $subject
            ]
        ],
        'from' => [
            'email' => 'babaibeji@gmail.com'
        ],
        'content' => [
            [
                'type' => 'text/plain',
                'value' => $content
            ]
        ]
    ];

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://rapidprod-sendgrid-v1.p.rapidapi.com/mail/send",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: rapidprod-sendgrid-v1.p.rapidapi.com",
            "X-RapidAPI-Key: " . $apiKey,
            "content-type: application/json"
        ],
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);

    if ($err) {
        echo "cURL Error for email $email: " . $err . "\n";
    } else {
        echo "Email sent successfully to $email\n";
    }
}

curl_close($curl);



/*

if(isset($_POST['send'])){
    // Form submitted, process the email sending

    $curl = curl_init();

    $recipientsString = $_POST['recipients'];
    $recipients = explode(',', $recipientsString);
    $subject = $_POST['subject'];
    $content = $_POST['content'];
    $apiKey = '01490c4942mshd375ca8a168def8p1bc00ajsnbda41e289d89'; // Replace with your SendGrid API key

    foreach ($recipients as $email) {
        $email = trim($email); // Trim whitespace around email address

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email address: $email";
            continue; // Skip invalid email address and move to the next iteration
        }

        $data = [
            'personalizations' => [
                [
                    'to' => [
                        ['email' => $email]
                    ],
                    'subject' => $subject
                ]
            ],
            'from' => [
                'email' => 'BODTECH'
            ],
            'content' => [
                [
                    'type' => 'text/plain',
                    'value' => $content
                ]
            ]
        ];

        
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://rapidprod-sendgrid-v1.p.rapidapi.com/mail/send",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                "X-RapidAPI-Host: rapidprod-sendgrid-v1.p.rapidapi.com",
                "X-RapidAPI-Key: " . $apiKey,
                "content-type: application/json"
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        if ($err) {
            echo "cURL Error for email $email: " . $err . "\n";
        } else {
            echo "Email sent successfully to $email\n";
        }
    }

    curl_close($curl);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Send Email Form</title>
</head>
<body>
    <h2>Send Email</h2>
    <form method="POST" action="">
        <label for="recipients">Recipients (comma-separated):</label><br>
        <input type="text" name="recipients" id="recipients" required><br><br>
        <label for="subject">Subject:</label><br>
        <input type="text" name="subject" id="subject" required><br><br>
        <label for="content">Content:</label><br>
        <textarea name="content" id="content" rows="4" required></textarea><br><br>
        <INPUT type="submit" name="send" value="send emails">
    </form>
</body>
</html>
*/