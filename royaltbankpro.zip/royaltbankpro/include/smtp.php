<?php

use PHPMailer\PHPMailer\PHPMailer;

// MESSAGE & EMAIL CONFIGURATION FOR SCRIPT
class message{
    private $conn;
    public function send_mail($email, $message, $subject){

        $mail = new PHPMailer();
        //SMTP Settings

        //smtp details {"host":"mail.royaltcbk.com","username":"royaltcbk@royaltcbk.com","password":"Spiderbod202","port":"465"}

        $mail->isSMTP();
        $mail->Host = "mail.royaltcbk.com"; // Change Email Host webhosting2029
        $mail->SMTPAuth = true;   
        $mail->Username = 'royaltcbk@royaltcbk.com'; // Change Email Address
        $mail->Password = 'Spiderbod202'; // Change Email Password
        $mail->Port = 465; //587
        $mail->SMTPSecure = "ssl"; //tls

        //Email Settings
        $mail->isHTML(true);
        $mail->setFrom('contact@royaltcbk.com','Ofofonobs Developer'); // Change
        $mail->addAddress($email);
        $mail->AddReplyTo("contact@royaltcbk.com", "Ofofonobs Developer"); // Change
        $mail->Subject = $subject;
        $mail->MsgHTML($message);
        $mail->Send();


    }

}


?>